## Pterodactyl Language System (1.x.x)

* Download the latest release, unzip and add all the files into /var/www/pterodactyl (Replace files if asked)
* Get your custom language [from here](https://github.com/yesBad/pterodactyl-custom-translations/tree/langs)
* Follow [this guide](https://pterodactyl.io/community/customization/panel.html) and you are done
